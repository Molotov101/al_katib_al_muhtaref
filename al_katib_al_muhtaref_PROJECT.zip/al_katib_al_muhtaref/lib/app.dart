import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:easy_localization/easy_localization.dart';
import 'core/themes/theme_provider.dart';
import 'presentation/providers/settings_provider.dart';
import 'presentation/screens/home_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final settingsProvider = Provider.of<SettingsProvider>(context);

    return MaterialApp(
      title: 'app_title'.tr(),
      debugShowCheckedModeBanner: false,
      localizationsDelegates: context.localizationDelegates,
      supportedLocales: context.supportedLocales,
      locale: context.locale,
      theme: AppThemes.buildLightTheme(
        settingsProvider.primaryColor,
        settingsProvider.fontFamily,
      ),
      darkTheme: AppThemes.buildDarkTheme(
        settingsProvider.primaryColor,
        settingsProvider.fontFamily,
      ),
      themeMode: themeProvider.themeMode,
      home: const HomeScreen(),
    );
  }
}
