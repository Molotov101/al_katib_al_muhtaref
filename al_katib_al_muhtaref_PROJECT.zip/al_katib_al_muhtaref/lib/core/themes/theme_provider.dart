import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../constants/app_colors.dart';
import '../utils/font_helper.dart';

class ThemeProvider extends ChangeNotifier {
  final SharedPreferences prefs;
  ThemeMode _themeMode = ThemeMode.system;

  ThemeProvider(this.prefs) {
    _themeMode = _getThemeModeFromPrefs();
  }

  ThemeMode get themeMode => _themeMode;

  ThemeMode _getThemeModeFromPrefs() {
    final value = prefs.getString('theme_mode') ?? 'system';
    switch (value) {
      case 'light':
        return ThemeMode.light;
      case 'dark':
        return ThemeMode.dark;
      default:
        return ThemeMode.system;
    }
  }

  Future<void> loadThemePreference() async {
    _themeMode = _getThemeModeFromPrefs();
    notifyListeners();
  }

  void toggleTheme() {
    if (_themeMode == ThemeMode.light) {
      _themeMode = ThemeMode.dark;
      prefs.setString('theme_mode', 'dark');
    } else if (_themeMode == ThemeMode.dark) {
      _themeMode = ThemeMode.light;
      prefs.setString('theme_mode', 'light');
    } else {
      _themeMode = ThemeMode.light;
      prefs.setString('theme_mode', 'light');
    }
    notifyListeners();
  }

  void setThemeMode(ThemeMode mode) {
    _themeMode = mode;
    String value = 'system';
    if (mode == ThemeMode.light) value = 'light';
    if (mode == ThemeMode.dark) value = 'dark';
    prefs.setString('theme_mode', value);
    notifyListeners();
  }

  void autoDetectTheme() {
    final hour = DateTime.now().hour;
    if (hour >= 6 && hour < 18) {
      _themeMode = ThemeMode.light;
      prefs.setString('theme_mode', 'light');
    } else {
      _themeMode = ThemeMode.dark;
      prefs.setString('theme_mode', 'dark');
    }
    notifyListeners();
  }
}

class AppThemes {
  // ملاحظة تصحيح: بدل تمرير fontFamily مباشرة إلى ThemeData(fontFamily: ...)
  // (وهو ما يتطلب ملفات .ttf مُجمَّعة يدوياً في assets/fonts/ ومُعرَّفة في
  // pubspec.yaml)، نبني TextTheme عبر FontHelper الذي يستخدم حزمة
  // google_fonts فتُجلب الخطوط تلقائياً دون أي إعداد يدوي.
  static ThemeData buildLightTheme(Color primaryColor, String fontFamily) {
    final base = ThemeData(
      brightness: Brightness.light,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: AppColors.backgroundLight,
      colorScheme: ColorScheme.light(
        primary: primaryColor,
        secondary: AppColors.secondary,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.secondary,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: AppColors.cardLight,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
    );
    return base.copyWith(
      textTheme: FontHelper.textTheme(fontFamily, base.textTheme),
      primaryTextTheme: FontHelper.textTheme(fontFamily, base.primaryTextTheme),
    );
  }

  static ThemeData buildDarkTheme(Color primaryColor, String fontFamily) {
    final base = ThemeData(
      brightness: Brightness.dark,
      primaryColor: primaryColor,
      scaffoldBackgroundColor: AppColors.backgroundDark,
      colorScheme: ColorScheme.dark(
        primary: primaryColor,
        secondary: AppColors.secondaryDark,
      ),
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.secondaryDark,
        foregroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      cardTheme: CardThemeData(
        color: AppColors.cardDark,
        elevation: 2,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
      ),
    );
    return base.copyWith(
      textTheme: FontHelper.textTheme(fontFamily, base.textTheme),
      primaryTextTheme: FontHelper.textTheme(fontFamily, base.primaryTextTheme),
    );
  }
}
