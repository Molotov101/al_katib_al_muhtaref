import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// مساعد موحّد للخطوط يعتمد على حزمة google_fonts بدل تحميل ملفات .ttf
/// يدوياً ووضعها في assets/fonts/. الحزمة تجلب الخط المطلوب تلقائياً من
/// خوادم Google أول مرة يُستخدم فيها (ثم تُخزَّن محلياً على الجهاز)،
/// فلا حاجة لأي تحميل يدوي أو تسمية ملفات بدقة.
///
/// ملاحظة: يتطلب هذا اتصالاً بالإنترنت أول مرة يُعرض فيها كل خط. إذا كنت
/// تريد عملاً كاملاً دون إنترنت من أول تشغيل، راجع توثيق google_fonts حول
/// "Bundling fonts in assets" لتضمين الخطوط داخل التطبيق وقت البناء.
class FontHelper {
  /// أسماء الخطوط كما تُعرف تماماً في كتالوج Google Fonts (يجب أن تُطابق
  /// هذه الأسماء حرفياً حتى تعمل GoogleFonts.getFont بدون خطأ).
  static const List<String> availableFonts = [
    'Cairo',
    'Amiri',
    'Noto Naskh Arabic',
  ];

  static TextStyle textStyle(
    String fontFamily, {
    double? fontSize,
    Color? color,
    FontWeight? fontWeight,
    FontStyle? fontStyle,
  }) {
    try {
      return GoogleFonts.getFont(
        fontFamily,
        fontSize: fontSize,
        color: color,
        fontWeight: fontWeight,
        fontStyle: fontStyle,
      );
    } catch (_) {
      // في حال اسم خط غير معروف أو تعذّر الجلب، نرجع لخط النظام الافتراضي
      // بدل رمي استثناء يوقف الواجهة بالكامل.
      return TextStyle(
        fontSize: fontSize,
        color: color,
        fontWeight: fontWeight,
        fontStyle: fontStyle,
      );
    }
  }

  static TextTheme textTheme(String fontFamily, TextTheme base) {
    try {
      return GoogleFonts.getTextTheme(fontFamily, base);
    } catch (_) {
      return base;
    }
  }
}
