import 'package:hive_flutter/hive_flutter.dart';
import '../models/project.dart';
import '../models/scene.dart';
import '../models/character.dart';
import '../models/image_asset.dart';

class DatabaseService {
  static const String projectsBox = 'projects';
  static const String scenesBox = 'scenes';
  static const String charactersBox = 'characters';
  static const String imagesBox = 'images';

  late Box<Project> _projectsBox;
  late Box<Scene> _scenesBox;
  late Box<Character> _charactersBox;
  late Box<ImageAsset> _imagesBox;

  Future<void> init() async {
    await Hive.initFlutter();

    // تسجيل المحولات (مرة واحدة فقط لتفادي خطأ "already registered")
    if (!Hive.isAdapterRegistered(0)) {
      Hive.registerAdapter(ProjectAdapter());
    }
    if (!Hive.isAdapterRegistered(1)) {
      Hive.registerAdapter(SceneAdapter());
    }
    if (!Hive.isAdapterRegistered(2)) {
      Hive.registerAdapter(CharacterAdapter());
    }
    if (!Hive.isAdapterRegistered(3)) {
      Hive.registerAdapter(ImageAssetAdapter());
    }

    // فتح الصناديق
    _projectsBox = await Hive.openBox<Project>(projectsBox);
    _scenesBox = await Hive.openBox<Scene>(scenesBox);
    _charactersBox = await Hive.openBox<Character>(charactersBox);
    _imagesBox = await Hive.openBox<ImageAsset>(imagesBox);
  }

  // ====== المشاريع ======
  Box<Project> get projects => _projectsBox;

  Future<void> saveProject(Project project) async {
    project.updatedAt = DateTime.now();
    await _projectsBox.put(project.id, project);
  }

  List<Project> getAllProjects() {
    return _projectsBox.values.toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  Project? getProject(String id) => _projectsBox.get(id);

  Future<void> deleteProject(String id) async {
    final project = _projectsBox.get(id);
    if (project != null) {
      // نسخ القوائم قبل التكرار عليها، لأن deleteScene/deleteCharacter
      // تُعدّل project.scenesIds/charactersIds أثناء التكرار في بعض الحالات.
      for (var sceneId in List<String>.from(project.scenesIds)) {
        await deleteScene(sceneId);
      }
      for (var charId in List<String>.from(project.charactersIds)) {
        await deleteCharacter(charId);
      }
      await _projectsBox.delete(id);
    }
  }

  // ====== المشاهد ======
  Box<Scene> get scenes => _scenesBox;

  Future<void> saveScene(Scene scene) async {
    scene.updatedAt = DateTime.now();
    await _scenesBox.put(scene.id, scene);
  }

  List<Scene> getScenesForProject(String projectId) {
    return _scenesBox.values
        .where((scene) => scene.projectId == projectId)
        .toList()
      ..sort((a, b) => a.number.compareTo(b.number));
  }

  Scene? getScene(String id) => _scenesBox.get(id);

  Future<void> deleteScene(String id) async {
    final images = getImagesForScene(id);
    for (var image in images) {
      await _imagesBox.delete(image.id);
    }
    await _scenesBox.delete(id);
  }

  int getNextSceneNumber(String projectId) {
    final scenes = getScenesForProject(projectId);
    return scenes.isEmpty ? 1 : scenes.last.number + 1;
  }

  // ====== الشخصيات ======
  Box<Character> get characters => _charactersBox;

  Future<void> saveCharacter(Character character) async {
    character.updatedAt = DateTime.now();
    await _charactersBox.put(character.id, character);
  }

  List<Character> getCharactersForProject(String projectId) {
    return _charactersBox.values
        .where((char) => char.projectId == projectId)
        .toList()
      ..sort((a, b) => a.name.compareTo(b.name));
  }

  Character? getCharacter(String id) => _charactersBox.get(id);

  Future<void> deleteCharacter(String id) async {
    await _charactersBox.delete(id);
  }

  // ====== الصور ======
  Box<ImageAsset> get images => _imagesBox;

  Future<void> saveImage(ImageAsset image) async {
    await _imagesBox.put(image.id, image);
  }

  ImageAsset? getImage(String id) => _imagesBox.get(id);

  List<ImageAsset> getImagesForScene(String sceneId) {
    return _imagesBox.values.where((img) => img.sceneId == sceneId).toList();
  }

  Future<void> deleteImage(String id) async {
    await _imagesBox.delete(id);
  }

  // ====== الإحصائيات ======
  int countScenesByTime(String projectId, String timeOfDay) {
    return _scenesBox.values
        .where((scene) =>
            scene.projectId == projectId && scene.timeOfDay == timeOfDay)
        .length;
  }

  Map<String, int> getLocationStats(String projectId) {
    final Map<String, int> stats = {};
    for (var scene in getScenesForProject(projectId)) {
      if (scene.location.isNotEmpty) {
        stats[scene.location] = (stats[scene.location] ?? 0) + 1;
      }
    }
    return stats;
  }

  int getTotalPages(String projectId) {
    return getScenesForProject(projectId)
        .fold(0, (sum, scene) => sum + scene.pageCount);
  }

  Future<void> closeAll() async {
    await _projectsBox.close();
    await _scenesBox.close();
    await _charactersBox.close();
    await _imagesBox.close();
  }
}
