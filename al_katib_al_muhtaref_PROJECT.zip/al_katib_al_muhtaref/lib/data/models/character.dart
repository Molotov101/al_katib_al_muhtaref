import 'package:hive/hive.dart';

part 'character.g.dart';

@HiveType(typeId: 2)
class Character extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String projectId;

  @HiveField(2)
  String name;

  @HiveField(3)
  String age;

  @HiveField(4)
  String gender;

  @HiveField(5)
  String occupation;

  @HiveField(6)
  String personalityTraits;

  @HiveField(7)
  String goals;

  @HiveField(8)
  String background;

  @HiveField(9)
  String arc;

  @HiveField(10)
  List<String> relationships;

  @HiveField(11)
  String imagePath;

  @HiveField(12)
  List<String> appearsInScenes;

  @HiveField(13)
  String physicalDescription;

  @HiveField(14)
  String catchphrase;

  @HiveField(15)
  DateTime createdAt;

  @HiveField(16)
  DateTime updatedAt;

  Character({
    required this.id,
    required this.projectId,
    required this.name,
    this.age = '',
    this.gender = '',
    this.occupation = '',
    this.personalityTraits = '',
    this.goals = '',
    this.background = '',
    this.arc = '',
    List<String>? relationships,
    this.imagePath = '',
    List<String>? appearsInScenes,
    this.physicalDescription = '',
    this.catchphrase = '',
    DateTime? createdAt,
    DateTime? updatedAt,
  })  : relationships = relationships ?? <String>[],
        appearsInScenes = appearsInScenes ?? <String>[],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();
}
