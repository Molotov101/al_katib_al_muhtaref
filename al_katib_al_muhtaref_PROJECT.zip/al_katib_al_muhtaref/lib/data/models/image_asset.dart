import 'package:hive/hive.dart';

part 'image_asset.g.dart';

@HiveType(typeId: 3)
class ImageAsset extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String sceneId;

  @HiveField(2)
  String imagePath;

  @HiveField(3)
  double xPosition;

  @HiveField(4)
  double yPosition;

  @HiveField(5)
  double width;

  @HiveField(6)
  double height;

  @HiveField(7)
  double rotation;

  @HiveField(8)
  DateTime createdAt;

  ImageAsset({
    required this.id,
    required this.sceneId,
    required this.imagePath,
    this.xPosition = 0.0,
    this.yPosition = 0.0,
    this.width = 100.0,
    this.height = 100.0,
    this.rotation = 0.0,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();
}
