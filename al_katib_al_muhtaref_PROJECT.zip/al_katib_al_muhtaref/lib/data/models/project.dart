import 'package:flutter/material.dart';
import 'package:hive/hive.dart';

part 'project.g.dart';

@HiveType(typeId: 0)
class Project extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String title;

  @HiveField(2)
  String type; // film, series, play, novel, story, animation

  @HiveField(3)
  String logline;

  @HiveField(4)
  String synopsis;

  @HiveField(5)
  List<String> charactersIds;

  @HiveField(6)
  List<String> scenesIds;

  @HiveField(7)
  List<String> locationsIds;

  @HiveField(8)
  DateTime createdAt;

  @HiveField(9)
  DateTime updatedAt;

  @HiveField(10)
  String status; // idea, draft, review, final

  @HiveField(11)
  String coverImagePath;

  @HiveField(12)
  String author;

  @HiveField(13)
  int totalScenes;

  @HiveField(14)
  int totalPages;

  @HiveField(15)
  String language;

  @HiveField(16)
  List<String> translationLanguages;

  Project({
    required this.id,
    required this.title,
    required this.type,
    this.logline = '',
    this.synopsis = '',
    List<String>? charactersIds,
    List<String>? scenesIds,
    List<String>? locationsIds,
    DateTime? createdAt,
    DateTime? updatedAt,
    this.status = 'idea',
    this.coverImagePath = '',
    this.author = '',
    this.totalScenes = 0,
    this.totalPages = 0,
    this.language = 'ar',
    List<String>? translationLanguages,
  })  : charactersIds = charactersIds ?? <String>[],
        scenesIds = scenesIds ?? <String>[],
        locationsIds = locationsIds ?? <String>[],
        translationLanguages = translationLanguages ?? <String>[],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  String getTypeLabel() {
    switch (type) {
      case 'film':
        return 'فيلم';
      case 'series':
        return 'مسلسل';
      case 'play':
        return 'مسرحية';
      case 'novel':
        return 'رواية';
      case 'story':
        return 'قصة';
      case 'animation':
        return 'فيلم كرتون';
      default:
        return 'مشروع';
    }
  }

  IconData getTypeIcon() {
    switch (type) {
      case 'film':
        return Icons.movie;
      case 'series':
        return Icons.tv;
      case 'play':
        return Icons.theater_comedy;
      case 'novel':
        return Icons.book;
      case 'story':
        return Icons.description;
      case 'animation':
        return Icons.animation;
      default:
        return Icons.folder;
    }
  }
}
