import 'package:hive/hive.dart';

part 'scene.g.dart';

@HiveType(typeId: 1)
class Scene extends HiveObject {
  @HiveField(0)
  String id;

  @HiveField(1)
  String projectId;

  @HiveField(2)
  int number;

  @HiveField(3)
  String title;

  @HiveField(4)
  String location;

  @HiveField(5)
  String timeOfDay; // day, night, sunrise, sunset

  @HiveField(6)
  String description;

  @HiveField(7)
  String dialogue;

  @HiveField(8)
  List<String> charactersInScene;

  @HiveField(9)
  int pageCount;

  @HiveField(10)
  String status; // draft, in_progress, completed

  @HiveField(11)
  String notes;

  @HiveField(12)
  DateTime createdAt;

  @HiveField(13)
  DateTime updatedAt;

  @HiveField(14)
  String sceneHeading;

  @HiveField(15)
  String translation;

  @HiveField(16)
  List<String> imagePaths;

  @HiveField(17)
  String sceneType; // dialogue, action, montage

  Scene({
    required this.id,
    required this.projectId,
    required this.number,
    this.title = '',
    this.location = '',
    this.timeOfDay = 'day',
    this.description = '',
    this.dialogue = '',
    List<String>? charactersInScene,
    this.pageCount = 1,
    this.status = 'draft',
    this.notes = '',
    DateTime? createdAt,
    DateTime? updatedAt,
    this.sceneHeading = '',
    this.translation = '',
    List<String>? imagePaths,
    this.sceneType = 'dialogue',
  })  : charactersInScene = charactersInScene ?? <String>[],
        imagePaths = imagePaths ?? <String>[],
        createdAt = createdAt ?? DateTime.now(),
        updatedAt = updatedAt ?? DateTime.now();

  /// نسخ المشهد مع تعديل حقول محددة فقط، بدلاً من إعادة بناء الكائن يدوياً
  /// في كل شاشة (هذا يمنع تكرار الكود ونسيان حقل عند التحديث).
  Scene copyWith({
    String? title,
    String? location,
    String? timeOfDay,
    String? description,
    String? dialogue,
    List<String>? charactersInScene,
    int? pageCount,
    String? status,
    String? notes,
    String? sceneHeading,
    String? translation,
    List<String>? imagePaths,
    String? sceneType,
  }) {
    return Scene(
      id: id,
      projectId: projectId,
      number: number,
      title: title ?? this.title,
      location: location ?? this.location,
      timeOfDay: timeOfDay ?? this.timeOfDay,
      description: description ?? this.description,
      dialogue: dialogue ?? this.dialogue,
      charactersInScene: charactersInScene ?? this.charactersInScene,
      pageCount: pageCount ?? this.pageCount,
      status: status ?? this.status,
      notes: notes ?? this.notes,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
      sceneHeading: sceneHeading ?? this.sceneHeading,
      translation: translation ?? this.translation,
      imagePaths: imagePaths ?? this.imagePaths,
      sceneType: sceneType ?? this.sceneType,
    );
  }

  String get formattedSceneHeading {
    if (sceneHeading.isNotEmpty) return sceneHeading;
    final timeLabel = _getTimeLabel(timeOfDay);
    return 'المشهد $number - $location - $timeLabel';
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }
}
