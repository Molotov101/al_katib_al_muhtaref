import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:easy_localization/easy_localization.dart';
import 'app.dart';
import 'data/local_storage/database_service.dart';
import 'presentation/providers/project_provider.dart';
import 'presentation/providers/scene_provider.dart';
import 'presentation/providers/settings_provider.dart';
import 'presentation/providers/character_provider.dart';
import 'core/themes/theme_provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await EasyLocalization.ensureInitialized();

  final databaseService = DatabaseService();
  await databaseService.init();

  final prefs = await SharedPreferences.getInstance();
  final themeProvider = ThemeProvider(prefs);
  await themeProvider.loadThemePreference();

  final settingsProvider = SettingsProvider(prefs);
  await settingsProvider.loadSettings();

  runApp(
    EasyLocalization(
      supportedLocales: const [Locale('ar'), Locale('en')],
      path: 'assets/translations',
      fallbackLocale: const Locale('ar'),
      child: MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (_) => themeProvider),
          ChangeNotifierProvider(create: (_) => settingsProvider),
          ChangeNotifierProvider(create: (_) => ProjectProvider(databaseService)),
          ChangeNotifierProvider(create: (_) => SceneProvider(databaseService)),
          ChangeNotifierProvider(create: (_) => CharacterProvider(databaseService)),
        ],
        child: const MyApp(),
      ),
    ),
  );
}
