import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../data/models/character.dart';
import '../../data/local_storage/database_service.dart';

/// كان هذا الـ Provider مفقوداً في الدليل الأصلي رغم وجود نموذج Character
/// كاملاً ودوال التخزين الخاصة به في DatabaseService، مما يجعل ميزة
/// إدارة الشخصيات غير قابلة للاستخدام فعلياً من الواجهات.
class CharacterProvider extends ChangeNotifier {
  final DatabaseService _db;
  List<Character> _characters = [];
  Character? _currentCharacter;
  bool _isLoading = false;

  CharacterProvider(this._db);

  List<Character> get characters => _characters;
  Character? get currentCharacter => _currentCharacter;
  bool get isLoading => _isLoading;

  Future<void> loadCharacters(String projectId) async {
    _isLoading = true;
    notifyListeners();
    _characters = _db.getCharactersForProject(projectId);
    _isLoading = false;
    notifyListeners();
  }

  Character? findById(String id) {
    for (final c in _characters) {
      if (c.id == id) return c;
    }
    return null;
  }

  Future<Character> createCharacter({
    required String projectId,
    required String name,
    String age = '',
    String gender = '',
    String occupation = '',
    String personalityTraits = '',
    String goals = '',
    String background = '',
    String physicalDescription = '',
  }) async {
    final id = const Uuid().v4();
    final character = Character(
      id: id,
      projectId: projectId,
      name: name,
      age: age,
      gender: gender,
      occupation: occupation,
      personalityTraits: personalityTraits,
      goals: goals,
      background: background,
      physicalDescription: physicalDescription,
    );
    await _db.saveCharacter(character);

    final project = _db.getProject(projectId);
    if (project != null) {
      project.charactersIds.add(id);
      await _db.saveProject(project);
    }

    _characters.add(character);
    _characters.sort((a, b) => a.name.compareTo(b.name));
    notifyListeners();
    return character;
  }

  Future<void> updateCharacter(Character character) async {
    await _db.saveCharacter(character);
    final index = _characters.indexWhere((c) => c.id == character.id);
    if (index != -1) {
      _characters[index] = character;
    }
    if (_currentCharacter?.id == character.id) {
      _currentCharacter = character;
    }
    notifyListeners();
  }

  Future<void> deleteCharacter(String id) async {
    final character = _db.getCharacter(id);
    await _db.deleteCharacter(id);
    _characters.removeWhere((c) => c.id == id);

    if (character != null) {
      final project = _db.getProject(character.projectId);
      if (project != null) {
        project.charactersIds.remove(id);
        await _db.saveProject(project);
      }
    }

    if (_currentCharacter?.id == id) {
      _currentCharacter = null;
    }
    notifyListeners();
  }

  void setCurrentCharacter(Character character) {
    _currentCharacter = character;
    notifyListeners();
  }

  void clearCurrentCharacter() {
    _currentCharacter = null;
    notifyListeners();
  }
}
