import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../data/models/project.dart';
import '../../data/local_storage/database_service.dart';

class ProjectProvider extends ChangeNotifier {
  final DatabaseService _db;
  List<Project> _projects = [];
  Project? _currentProject;
  bool _isLoading = false;

  ProjectProvider(this._db) {
    loadProjects();
  }

  List<Project> get projects => _projects;
  Project? get currentProject => _currentProject;
  bool get isLoading => _isLoading;

  Future<void> loadProjects() async {
    _isLoading = true;
    notifyListeners();
    _projects = _db.getAllProjects();
    _isLoading = false;
    notifyListeners();
  }

  /// إرجاع المشروع من القائمة إن وجد، بدون رمي استثناء إن لم يوجد
  /// (يصحح استخدام firstWhere بدون orElse الذي كان يسبب Crash في الشاشات).
  Project? findById(String id) {
    for (final p in _projects) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<Project> createProject({
    required String title,
    required String type,
    String logline = '',
    String synopsis = '',
    String author = '',
    String language = 'ar',
  }) async {
    final id = const Uuid().v4();
    final project = Project(
      id: id,
      title: title,
      type: type,
      logline: logline,
      synopsis: synopsis,
      author: author,
      language: language,
    );
    await _db.saveProject(project);
    _projects.insert(0, project);
    notifyListeners();
    return project;
  }

  Future<void> updateProject(Project project) async {
    await _db.saveProject(project);
    final index = _projects.indexWhere((p) => p.id == project.id);
    if (index != -1) {
      _projects[index] = project;
    }
    if (_currentProject?.id == project.id) {
      _currentProject = project;
    }
    notifyListeners();
  }

  Future<void> deleteProject(String id) async {
    await _db.deleteProject(id);
    _projects.removeWhere((p) => p.id == id);
    if (_currentProject?.id == id) {
      _currentProject = null;
    }
    notifyListeners();
  }

  void setCurrentProject(Project project) {
    _currentProject = project;
    notifyListeners();
  }

  void clearCurrentProject() {
    _currentProject = null;
    notifyListeners();
  }
}
