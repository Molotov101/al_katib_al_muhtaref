import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../data/models/scene.dart';
import '../../data/models/image_asset.dart';
import '../../data/local_storage/database_service.dart';

class SceneProvider extends ChangeNotifier {
  final DatabaseService _db;
  List<Scene> _scenes = [];
  Scene? _currentScene;
  bool _isLoading = false;

  SceneProvider(this._db);

  List<Scene> get scenes => _scenes;
  Scene? get currentScene => _currentScene;
  bool get isLoading => _isLoading;

  Future<void> loadScenes(String projectId) async {
    _isLoading = true;
    notifyListeners();
    _scenes = _db.getScenesForProject(projectId);
    _isLoading = false;
    notifyListeners();
  }

  /// إرجاع المشهد من القائمة إن وجد، بدون رمي استثناء (يصحح firstWhere
  /// بدون orElse المستخدم سابقاً في editor_screen.dart).
  Scene? findById(String id) {
    for (final s in _scenes) {
      if (s.id == id) return s;
    }
    return null;
  }

  Future<Scene> createScene({
    required String projectId,
    required String title,
    String location = '',
    String timeOfDay = 'day',
    String description = '',
    String dialogue = '',
    List<String> characters = const [],
    String notes = '',
    String sceneType = 'dialogue',
  }) async {
    final id = const Uuid().v4();
    final number = _db.getNextSceneNumber(projectId);
    final scene = Scene(
      id: id,
      projectId: projectId,
      number: number,
      title: title,
      location: location,
      timeOfDay: timeOfDay,
      description: description,
      dialogue: dialogue,
      charactersInScene: List<String>.from(characters),
      notes: notes,
      sceneType: sceneType,
    );
    await _db.saveScene(scene);
    final project = _db.getProject(projectId);
    if (project != null) {
      project.totalScenes = _db.getScenesForProject(projectId).length;
      project.scenesIds.add(id);
      await _db.saveProject(project);
    }
    _scenes.add(scene);
    _scenes.sort((a, b) => a.number.compareTo(b.number));
    notifyListeners();
    return scene;
  }

  Future<void> updateScene(Scene scene) async {
    await _db.saveScene(scene);
    final index = _scenes.indexWhere((s) => s.id == scene.id);
    if (index != -1) {
      _scenes[index] = scene;
    }
    if (_currentScene?.id == scene.id) {
      _currentScene = scene;
    }
    notifyListeners();
  }

  Future<void> deleteScene(String id) async {
    final scene = _db.getScene(id);
    if (scene != null) {
      await _db.deleteScene(id);
      _scenes.removeWhere((s) => s.id == id);
      for (var i = 0; i < _scenes.length; i++) {
        if (_scenes[i].number != i + 1) {
          _scenes[i].number = i + 1;
          await _db.saveScene(_scenes[i]);
        }
      }
      final project = _db.getProject(scene.projectId);
      if (project != null) {
        project.totalScenes = _scenes.length;
        project.scenesIds.remove(id);
        await _db.saveProject(project);
      }
      if (_currentScene?.id == id) {
        _currentScene = null;
      }
      notifyListeners();
    }
  }

  void setCurrentScene(Scene scene) {
    _currentScene = scene;
    notifyListeners();
  }

  void clearCurrentScene() {
    _currentScene = null;
    notifyListeners();
  }

  // ====== إدارة الصور ======
  Future<void> addImageToScene(String sceneId, String imagePath) async {
    final id = const Uuid().v4();
    final image = ImageAsset(
      id: id,
      sceneId: sceneId,
      imagePath: imagePath,
    );
    await _db.saveImage(image);

    final scene = _db.getScene(sceneId);
    if (scene != null) {
      scene.imagePaths.add(imagePath);
      await _db.saveScene(scene);
      if (_currentScene?.id == sceneId) {
        _currentScene = scene;
      }
      final index = _scenes.indexWhere((s) => s.id == sceneId);
      if (index != -1) {
        _scenes[index] = scene;
      }
      notifyListeners();
    }
  }

  Future<void> updateImagePosition(
    String imageId,
    double x,
    double y,
    double width,
    double height,
  ) async {
    final image = _db.getImage(imageId);
    if (image != null) {
      image.xPosition = x;
      image.yPosition = y;
      image.width = width;
      image.height = height;
      await _db.saveImage(image);
      notifyListeners();
    }
  }

  Future<void> deleteImage(String imageId) async {
    await _db.deleteImage(imageId);
    notifyListeners();
  }

  List<ImageAsset> getImagesForScene(String sceneId) {
    return _db.getImagesForScene(sceneId);
  }
}
