import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsProvider extends ChangeNotifier {
  final SharedPreferences prefs;
  String _defaultLanguage = 'ar';
  bool _autoDetectTheme = true;
  String _fontFamily = 'Cairo';
  double _fontSize = 16.0;
  Color _primaryColor = const Color(0xFFD4AF37);
  Color _textColor = Colors.black;
  String _scriptType = 'film';
  final List<String> _availableLanguages = ['ar', 'en', 'fr', 'es', 'de'];

  SettingsProvider(this.prefs) {
    _loadSettings();
  }

  void _loadSettings() {
    _defaultLanguage = prefs.getString('default_language') ?? 'ar';
    _autoDetectTheme = prefs.getBool('auto_detect_theme') ?? true;
    _fontFamily = prefs.getString('font_family') ?? 'Cairo';
    _fontSize = prefs.getDouble('font_size') ?? 16.0;
    _primaryColor = Color(prefs.getInt('primary_color') ?? 0xFFD4AF37);
    _textColor = Color(prefs.getInt('text_color') ?? 0xFF000000);
    _scriptType = prefs.getString('script_type') ?? 'film';
  }

  String get defaultLanguage => _defaultLanguage;
  bool get autoDetectTheme => _autoDetectTheme;
  String get fontFamily => _fontFamily;
  double get fontSize => _fontSize;
  Color get primaryColor => _primaryColor;
  Color get textColor => _textColor;
  String get scriptType => _scriptType;
  List<String> get availableLanguages => _availableLanguages;

  Future<void> loadSettings() async {
    _loadSettings();
    notifyListeners();
  }

  void setDefaultLanguage(String lang) {
    _defaultLanguage = lang;
    prefs.setString('default_language', lang);
    notifyListeners();
  }

  void setAutoDetectTheme(bool value) {
    _autoDetectTheme = value;
    prefs.setBool('auto_detect_theme', value);
    notifyListeners();
  }

  void setFontFamily(String font) {
    _fontFamily = font;
    prefs.setString('font_family', font);
    notifyListeners();
  }

  void setFontSize(double size) {
    _fontSize = size;
    prefs.setDouble('font_size', size);
    notifyListeners();
  }

  void setPrimaryColor(Color color) {
    _primaryColor = color;
    // ملاحظة تصحيح: color.value أصبحت مهملة (deprecated) في Flutter الحديث.
    // البديل الرسمي هو toARGB32() للحصول على قيمة int لتخزينها.
    prefs.setInt('primary_color', color.toARGB32());
    notifyListeners();
  }

  void setTextColor(Color color) {
    _textColor = color;
    prefs.setInt('text_color', color.toARGB32());
    notifyListeners();
  }

  void setScriptType(String type) {
    _scriptType = type;
    prefs.setString('script_type', type);
    notifyListeners();
  }

  String getLanguageName(String code) {
    switch (code) {
      case 'ar':
        return 'العربية';
      case 'en':
        return 'English';
      case 'fr':
        return 'Français';
      case 'es':
        return 'Español';
      case 'de':
        return 'Deutsch';
      default:
        return code;
    }
  }
}
