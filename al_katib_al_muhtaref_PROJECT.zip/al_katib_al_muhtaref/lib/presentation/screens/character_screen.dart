import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/character_provider.dart';
import '../widgets/character_card.dart';

/// شاشة إدارة الشخصيات، كانت غائبة تماماً في الدليل الأصلي رغم وجود
/// نموذج Character كامل ودعمه في قاعدة البيانات.
class CharacterScreen extends StatefulWidget {
  final String projectId;
  const CharacterScreen({super.key, required this.projectId});

  @override
  State<CharacterScreen> createState() => _CharacterScreenState();
}

class _CharacterScreenState extends State<CharacterScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Provider.of<CharacterProvider>(context, listen: false)
          .loadCharacters(widget.projectId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<CharacterProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('الشخصيات')),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : provider.characters.isEmpty
              ? const Center(child: Text('لا توجد شخصيات بعد'))
              : ListView.builder(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  itemCount: provider.characters.length,
                  itemBuilder: (context, index) {
                    final character = provider.characters[index];
                    return CharacterCard(
                      character: character,
                      onDelete: () => provider.deleteCharacter(character.id),
                    );
                  },
                ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateCharacterDialog(context),
        icon: const Icon(Icons.person_add),
        label: const Text('شخصية جديدة'),
      ),
    );
  }

  void _showCreateCharacterDialog(BuildContext context) {
    final nameController = TextEditingController();
    final ageController = TextEditingController();
    final occupationController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('شخصية جديدة'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'الاسم'),
              autofocus: true,
            ),
            const SizedBox(height: 12),
            TextField(
              controller: ageController,
              decoration: const InputDecoration(labelText: 'العمر'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: occupationController,
              decoration: const InputDecoration(labelText: 'المهنة'),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (nameController.text.isNotEmpty) {
                final provider =
                    Provider.of<CharacterProvider>(context, listen: false);
                await provider.createCharacter(
                  projectId: widget.projectId,
                  name: nameController.text,
                  age: ageController.text,
                  occupation: occupationController.text,
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              }
            },
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
  }
}
