import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:image_picker/image_picker.dart';
import '../providers/scene_provider.dart';
import '../providers/settings_provider.dart';
import '../../data/models/scene.dart';
import '../../data/models/image_asset.dart';
import '../../core/utils/font_helper.dart';

class EditorScreen extends StatefulWidget {
  final String sceneId;
  const EditorScreen({super.key, required this.sceneId});

  @override
  State<EditorScreen> createState() => _EditorScreenState();
}

class _EditorScreenState extends State<EditorScreen> {
  final _dialogueController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _notesController = TextEditingController();
  final _titleController = TextEditingController();
  final _locationController = TextEditingController();
  String _selectedTime = 'day';
  String _selectedStatus = 'draft';
  List<ImageAsset> _images = [];
  bool _sceneNotFound = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _loadScene();
    });
  }

  void _loadScene() {
    final provider = Provider.of<SceneProvider>(context, listen: false);
    // ملاحظة تصحيح: findById الآمن بدل firstWhere الذي كان يرمي
    // StateError إذا لم يوجد المشهد (مثلاً بعد حذفه).
    final scene = provider.findById(widget.sceneId);
    if (scene == null) {
      setState(() => _sceneNotFound = true);
      return;
    }
    provider.setCurrentScene(scene);

    _dialogueController.text = scene.dialogue;
    _descriptionController.text = scene.description;
    _notesController.text = scene.notes;
    _titleController.text = scene.title;
    _locationController.text = scene.location;
    _selectedTime = scene.timeOfDay;
    _selectedStatus = scene.status;
    _images = provider.getImagesForScene(widget.sceneId);
    setState(() {});
  }

  @override
  void dispose() {
    _dialogueController.dispose();
    _descriptionController.dispose();
    _notesController.dispose();
    _titleController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_sceneNotFound) {
      return Scaffold(
        appBar: AppBar(title: const Text('المشهد')),
        body: const Center(child: Text('لم يتم العثور على هذا المشهد')),
      );
    }

    final sceneProvider = Provider.of<SceneProvider>(context);
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final scene = sceneProvider.currentScene;

    if (scene == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(scene.formattedSceneHeading),
        actions: [
          IconButton(
            icon: const Icon(Icons.image),
            onPressed: () => _pickImage(sceneProvider, scene.id),
            tooltip: 'إضافة صورة',
          ),
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: () => _saveScene(sceneProvider, scene),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: TextField(
                  controller: _titleController,
                  decoration: const InputDecoration(
                    labelText: 'عنوان المشهد',
                    border: InputBorder.none,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: TextField(
                        controller: _locationController,
                        decoration: const InputDecoration(
                          labelText: 'المكان',
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(8),
                      child: DropdownButtonFormField<String>(
                        value: _selectedTime,
                        decoration: const InputDecoration(
                          labelText: 'الوقت',
                          border: InputBorder.none,
                        ),
                        items: ['day', 'night', 'sunrise', 'sunset'].map((time) {
                          return DropdownMenuItem(
                            value: time,
                            child: Text(_getTimeLabel(time)),
                          );
                        }).toList(),
                        onChanged: (value) {
                          if (value != null) setState(() => _selectedTime = value);
                        },
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('وصف المشهد',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _descriptionController,
                      maxLines: 5,
                      decoration: const InputDecoration(
                        hintText: 'اكتب وصف المشهد هنا...',
                        border: InputBorder.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('الحوار',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _dialogueController,
                      maxLines: 10,
                      style: FontHelper.textStyle(
                        settingsProvider.fontFamily,
                        fontSize: settingsProvider.fontSize,
                        color: settingsProvider.textColor,
                      ),
                      decoration: const InputDecoration(
                        hintText: 'اكتب الحوار هنا...',
                        border: InputBorder.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            if (_images.isNotEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('الصور',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      SizedBox(
                        height: 120,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          itemCount: _images.length,
                          itemBuilder: (context, index) {
                            return _buildImageThumbnail(_images[index]);
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('ملاحظات الكاتب',
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    TextField(
                      controller: _notesController,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText: 'ملاحظاتك هنا...',
                        border: InputBorder.none,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: DropdownButtonFormField<String>(
                  value: _selectedStatus,
                  decoration: const InputDecoration(
                    labelText: 'حالة المشهد',
                    border: InputBorder.none,
                  ),
                  items: ['draft', 'in_progress', 'completed'].map((status) {
                    return DropdownMenuItem(
                      value: status,
                      child: Text({
                            'draft': 'مسودة',
                            'in_progress': 'قيد الكتابة',
                            'completed': 'مكتمل',
                          }[status] ??
                          status),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _selectedStatus = value);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _saveScene(sceneProvider, scene),
        child: const Icon(Icons.save),
      ),
    );
  }

  Widget _buildImageThumbnail(ImageAsset image) {
    return GestureDetector(
      onTap: () => _showImageEditor(image),
      child: Container(
        width: 100,
        height: 100,
        margin: const EdgeInsets.only(right: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(8),
          image: DecorationImage(
            image: FileImage(File(image.imagePath)),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: 4,
              right: 4,
              child: GestureDetector(
                onTap: () => _deleteImage(image.id),
                child: Container(
                  decoration: const BoxDecoration(
                    color: Colors.red,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close, size: 16, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _pickImage(SceneProvider provider, String sceneId) async {
    final picker = ImagePicker();
    final image = await picker.pickImage(source: ImageSource.gallery);
    if (image != null && mounted) {
      await provider.addImageToScene(sceneId, image.path);
      setState(() {
        _images = provider.getImagesForScene(sceneId);
      });
    }
  }

  void _showImageEditor(ImageAsset image) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('محرر الصور غير مكتمل بعد في هذه النسخة')),
    );
  }

  void _deleteImage(String imageId) async {
    final provider = Provider.of<SceneProvider>(context, listen: false);
    await provider.deleteImage(imageId);
    if (!mounted) return;
    setState(() {
      _images = provider.getImagesForScene(widget.sceneId);
    });
  }

  void _saveScene(SceneProvider provider, Scene scene) {
    // ملاحظة تصحيح: استخدام scene.copyWith بدل إعادة بناء الكائن يدوياً
    // في كل شاشة (كان هذا مصدر تكرار وخطأ محتمل عند نسيان حقل).
    final updatedScene = scene.copyWith(
      title: _titleController.text,
      location: _locationController.text,
      timeOfDay: _selectedTime,
      description: _descriptionController.text,
      dialogue: _dialogueController.text,
      pageCount: _calculatePageCount(),
      status: _selectedStatus,
      notes: _notesController.text,
    );

    provider.updateScene(updatedScene);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ المشهد بنجاح')),
    );
  }

  int _calculatePageCount() {
    final text = _dialogueController.text.trim();
    if (text.isEmpty) return 1;
    final totalWords = text.split(RegExp(r'\s+')).length;
    return (totalWords / 250).ceil() + 1;
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }
}
