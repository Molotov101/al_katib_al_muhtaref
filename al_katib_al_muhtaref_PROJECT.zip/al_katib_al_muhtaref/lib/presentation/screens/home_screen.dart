import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/project_provider.dart';
import '../providers/settings_provider.dart';
import '../../core/themes/theme_provider.dart';
import '../../data/models/project.dart';
import 'project_screen.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Provider.of<ProjectProvider>(context, listen: false).loadProjects();
    });
  }

  @override
  Widget build(BuildContext context) {
    final projectProvider = Provider.of<ProjectProvider>(context);
    final themeProvider = Provider.of<ThemeProvider>(context);
    final settingsProvider = Provider.of<SettingsProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الكاتب المحترف'),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.language),
            onSelected: (value) {
              settingsProvider.setDefaultLanguage(value);
            },
            itemBuilder: (context) {
              return settingsProvider.availableLanguages.map((lang) {
                return PopupMenuItem(
                  value: lang,
                  child: Text(settingsProvider.getLanguageName(lang)),
                );
              }).toList();
            },
          ),
          IconButton(
            icon: Icon(
              themeProvider.themeMode == ThemeMode.light
                  ? Icons.dark_mode
                  : Icons.light_mode,
            ),
            onPressed: () => themeProvider.toggleTheme(),
          ),
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          _buildHeader(context),
          Expanded(
            child: projectProvider.isLoading
                ? const Center(child: CircularProgressIndicator())
                : projectProvider.projects.isEmpty
                    ? _buildEmptyState(context)
                    : _buildProjectList(projectProvider),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateProjectDialog(context),
        icon: const Icon(Icons.add),
        label: const Text('مشروع جديد'),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
        borderRadius: const BorderRadius.only(
          bottomLeft: Radius.circular(30),
          bottomRight: Radius.circular(30),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('مرحباً بك في',
                  style: Theme.of(context).textTheme.bodyMedium),
              Text(
                'الكاتب المحترف',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: Theme.of(context).primaryColor,
                    ),
              ),
            ],
          ),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Theme.of(context).primaryColor,
            ),
            child: const Icon(Icons.edit, color: Colors.white),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.folder_open, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text('لا توجد مشاريع بعد',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text('اضغط على زر + لبدء مشروع جديد',
              style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildProjectList(ProjectProvider provider) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: provider.projects.length,
      itemBuilder: (context, index) {
        return _buildProjectCard(context, provider.projects[index]);
      },
    );
  }

  Widget _buildProjectCard(BuildContext context, Project project) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => ProjectScreen(projectId: project.id),
            ),
          );
        },
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: Theme.of(context).primaryColor.withValues(alpha: 0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  project.getTypeIcon(),
                  color: Theme.of(context).primaryColor,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(project.title,
                        style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          project.getTypeLabel(),
                          style: TextStyle(
                            color: Colors.grey.shade600,
                            fontSize: 12,
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: 8,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: _getStatusColor(project.status)
                                .withValues(alpha: 0.2),
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            _getStatusLabel(project.status),
                            style: TextStyle(
                              fontSize: 10,
                              color: _getStatusColor(project.status),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Text(
                '${project.totalScenes} مشهد',
                style: TextStyle(
                  color: Colors.grey.shade600,
                  fontSize: 12,
                ),
              ),
              const SizedBox(width: 8),
              Icon(
                Icons.arrow_forward_ios,
                size: 16,
                color: Colors.grey.shade400,
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'idea':
        return Colors.blue;
      case 'draft':
        return Colors.orange;
      case 'review':
        return Colors.purple;
      case 'final':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getStatusLabel(String status) {
    switch (status) {
      case 'idea':
        return 'فكرة';
      case 'draft':
        return 'مسودة';
      case 'review':
        return 'مراجعة';
      case 'final':
        return 'نهائي';
      default:
        return status;
    }
  }

  void _showCreateProjectDialog(BuildContext context) {
    final titleController = TextEditingController();
    String selectedType = 'film';
    String selectedLanguage = 'ar';

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('مشروع جديد'),
        // ملاحظة تصحيح: تم لف المحتوى بـ StatefulBuilder لأن الـ
        // DropdownButtonFormField لم يكن يعكس التغيير بصرياً في النسخة
        // الأصلية (الـ Dialog لم يكن Stateful).
        content: StatefulBuilder(
          builder: (context, setDialogState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'عنوان المشروع'),
                  autofocus: true,
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(labelText: 'نوع المشروع'),
                  items: [
                    'film',
                    'series',
                    'play',
                    'novel',
                    'story',
                    'animation'
                  ].map((type) {
                    return DropdownMenuItem(
                      value: type,
                      child: Text({
                            'film': 'فيلم',
                            'series': 'مسلسل',
                            'play': 'مسرحية',
                            'novel': 'رواية',
                            'story': 'قصة',
                            'animation': 'فيلم كرتون',
                          }[type] ??
                          type),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedType = value);
                    }
                  },
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedLanguage,
                  decoration: const InputDecoration(labelText: 'اللغة الأساسية'),
                  items: ['ar', 'en', 'fr', 'es', 'de'].map((lang) {
                    return DropdownMenuItem(
                      value: lang,
                      child: Text({
                            'ar': 'العربية',
                            'en': 'English',
                            'fr': 'Français',
                            'es': 'Español',
                            'de': 'Deutsch',
                          }[lang] ??
                          lang),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedLanguage = value);
                    }
                  },
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty) {
                final provider =
                    Provider.of<ProjectProvider>(context, listen: false);
                await provider.createProject(
                  title: titleController.text,
                  type: selectedType,
                  language: selectedLanguage,
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              }
            },
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
  }
}
