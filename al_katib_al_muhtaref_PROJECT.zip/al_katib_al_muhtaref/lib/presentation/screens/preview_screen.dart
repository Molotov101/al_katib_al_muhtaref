import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import '../providers/scene_provider.dart';
import '../../core/utils/font_helper.dart';
import '../providers/settings_provider.dart';
import '../../data/models/scene.dart';

class PreviewScreen extends StatefulWidget {
  final String projectId;
  const PreviewScreen({super.key, required this.projectId});

  @override
  State<PreviewScreen> createState() => _PreviewScreenState();
}

class _PreviewScreenState extends State<PreviewScreen> {
  List<Scene> _scenes = [];
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _loadData();
    });
  }

  void _loadData() {
    final sceneProvider = Provider.of<SceneProvider>(context, listen: false);
    _scenes = sceneProvider.scenes;
    setState(() => _loaded = true);
  }

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);

    if (!_loaded) {
      return Scaffold(
        appBar: AppBar(title: const Text('معاينة السيناريو')),
        body: const Center(child: CircularProgressIndicator()),
      );
    }

    if (_scenes.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('معاينة السيناريو')),
        body: const Center(child: Text('لا توجد مشاهد لعرضها')),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('معاينة السيناريو'),
        actions: [
          IconButton(
            icon: const Icon(Icons.text_fields),
            onPressed: () => _showFontSizeDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.color_lens),
            onPressed: () => _showColorPickerDialog(context),
          ),
          IconButton(
            icon: const Icon(Icons.font_download),
            onPressed: () => _showFontFamilyDialog(context),
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: _scenes.length,
        itemBuilder: (context, index) {
          return _buildScenePreview(context, _scenes[index], settingsProvider);
        },
      ),
    );
  }

  Widget _buildScenePreview(
    BuildContext context,
    Scene scene,
    SettingsProvider settings,
  ) {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Text(
                    'مشهد ${scene.number}',
                    style: FontHelper.textStyle(
                      settings.fontFamily,
                      fontWeight: FontWeight.bold,
                      fontSize: settings.fontSize + 2,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    scene.location,
                    style: FontHelper.textStyle(
                      settings.fontFamily,
                      fontSize: settings.fontSize,
                      color: Colors.grey.shade600,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                    decoration: BoxDecoration(
                      color: _getTimeColor(scene.timeOfDay).withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      _getTimeLabel(scene.timeOfDay),
                      style: TextStyle(
                        fontSize: settings.fontSize - 2,
                        color: _getTimeColor(scene.timeOfDay),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            if (scene.description.isNotEmpty)
              Text(
                scene.description,
                style: FontHelper.textStyle(
                  settings.fontFamily,
                  fontSize: settings.fontSize,
                  color: settings.textColor,
                  fontStyle: FontStyle.italic,
                ),
              ),
            if (scene.description.isNotEmpty) const SizedBox(height: 12),
            if (scene.dialogue.isNotEmpty)
              Text(
                scene.dialogue,
                style: FontHelper.textStyle(
                  settings.fontFamily,
                  fontSize: settings.fontSize,
                  color: settings.textColor,
                ),
              ),
            if (scene.dialogue.isNotEmpty) const SizedBox(height: 8),
            if (scene.notes.isNotEmpty)
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  '📝 ${scene.notes}',
                  style: FontHelper.textStyle(
                    settings.fontFamily,
                    fontSize: settings.fontSize - 2,
                    color: Colors.grey.shade600,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  void _showFontSizeDialog(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context, listen: false);
    double tempSize = settingsProvider.fontSize;

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حجم الخط'),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Slider(
                  value: tempSize,
                  min: 10,
                  max: 30,
                  divisions: 20,
                  label: tempSize.toStringAsFixed(1),
                  onChanged: (value) {
                    setState(() => tempSize = value);
                  },
                ),
                Text('الحجم الحالي: ${tempSize.toStringAsFixed(1)}'),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              settingsProvider.setFontSize(tempSize);
              Navigator.pop(dialogContext);
            },
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
  }

  void _showColorPickerDialog(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context, listen: false);
    Color selectedColor = settingsProvider.textColor;

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('لون النص'),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: selectedColor,
            onColorChanged: (color) {
              selectedColor = color;
            },
            pickerAreaHeightPercent: 0.7,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          TextButton(
            onPressed: () {
              settingsProvider.setTextColor(selectedColor);
              Navigator.pop(dialogContext);
            },
            child: const Text('تطبيق'),
          ),
        ],
      ),
    );
  }

  void _showFontFamilyDialog(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context, listen: false);

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('نوع الخط'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              title: const Text('Cairo'),
              leading: const Icon(Icons.font_download),
              onTap: () {
                settingsProvider.setFontFamily('Cairo');
                Navigator.pop(dialogContext);
              },
            ),
            ListTile(
              title: const Text('Amiri'),
              leading: const Icon(Icons.font_download),
              onTap: () {
                settingsProvider.setFontFamily('Amiri');
                Navigator.pop(dialogContext);
              },
            ),
            ListTile(
              title: const Text('Noto Naskh Arabic'),
              leading: const Icon(Icons.font_download),
              onTap: () {
                settingsProvider.setFontFamily('Noto Naskh Arabic');
                Navigator.pop(dialogContext);
              },
            ),
          ],
        ),
      ),
    );
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }

  Color _getTimeColor(String time) {
    switch (time) {
      case 'day':
        return Colors.amber;
      case 'night':
        return Colors.indigo;
      case 'sunrise':
        return Colors.orange;
      case 'sunset':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }
}
