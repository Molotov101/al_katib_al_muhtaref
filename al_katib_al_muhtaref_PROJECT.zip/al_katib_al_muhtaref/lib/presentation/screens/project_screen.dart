import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/project_provider.dart';
import '../providers/scene_provider.dart';
import '../../data/models/project.dart';
import '../../data/models/scene.dart';
import '../../services/export_service.dart';
import '../../services/print_service.dart';
import 'editor_screen.dart';
import 'translation_screen.dart';
import 'preview_screen.dart';
import 'character_screen.dart';

class ProjectScreen extends StatefulWidget {
  final String projectId;
  const ProjectScreen({super.key, required this.projectId});

  @override
  State<ProjectScreen> createState() => _ProjectScreenState();
}

class _ProjectScreenState extends State<ProjectScreen> {
  final _exportService = ExportService();
  final _printService = PrintService();
  bool _isBusy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final projectProvider =
          Provider.of<ProjectProvider>(context, listen: false);
      // ملاحظة تصحيح: استخدام findById الآمن بدل firstWhere الذي كان
      // يرمي StateError ويوقف التطبيق إن لم يوجد المشروع.
      final project = projectProvider.findById(widget.projectId);
      if (project != null) {
        projectProvider.setCurrentProject(project);
      }
      Provider.of<SceneProvider>(context, listen: false)
          .loadScenes(widget.projectId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final projectProvider = Provider.of<ProjectProvider>(context);
    final sceneProvider = Provider.of<SceneProvider>(context);
    final project = projectProvider.currentProject;

    if (project == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(project.title),
        actions: [
          IconButton(
            icon: const Icon(Icons.preview),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => PreviewScreen(projectId: project.id),
              ),
            ),
            tooltip: 'معاينة النص',
          ),
          IconButton(
            icon: _isBusy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.print),
            onPressed: _isBusy
                ? null
                : () => _printScript(context, project, sceneProvider.scenes),
            tooltip: 'طباعة السيناريو',
          ),
          IconButton(
            icon: const Icon(Icons.translate),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => TranslationScreen(projectId: project.id),
              ),
            ),
            tooltip: 'ترجمة ودبلجة السيناريو',
          ),
          IconButton(
            icon: const Icon(Icons.people),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => CharacterScreen(projectId: project.id),
              ),
            ),
            tooltip: 'الشخصيات',
          ),
          IconButton(
            icon: const Icon(Icons.file_download),
            onPressed: _isBusy
                ? null
                : () => _exportScript(context, project, sceneProvider.scenes),
            tooltip: 'تصدير السيناريو',
          ),
        ],
      ),
      body: Column(
        children: [
          _buildProjectInfo(context, project, sceneProvider),
          Expanded(
            child: sceneProvider.isLoading
                ? const Center(child: CircularProgressIndicator())
                : sceneProvider.scenes.isEmpty
                    ? _buildEmptyScenes(context)
                    : _buildScenesList(sceneProvider),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _showCreateSceneDialog(context, project.id),
        icon: const Icon(Icons.add),
        label: const Text('مشهد جديد'),
      ),
    );
  }

  Widget _buildProjectInfo(
      BuildContext context, Project project, SceneProvider sceneProvider) {
    final dayCount =
        sceneProvider.scenes.where((s) => s.timeOfDay == 'day').length;
    final nightCount =
        sceneProvider.scenes.where((s) => s.timeOfDay == 'night').length;
    final totalPages =
        sceneProvider.scenes.fold(0, (sum, s) => sum + s.pageCount);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Theme.of(context).primaryColor.withValues(alpha: 0.05),
        border: Border(
          bottom: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      child: Row(
        children: [
          Icon(project.getTypeIcon(), color: Theme.of(context).primaryColor),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${sceneProvider.scenes.length} مشهد',
                    style: const TextStyle(fontSize: 12)),
                Row(
                  children: [
                    _buildStatChip('نهار: $dayCount'),
                    const SizedBox(width: 8),
                    _buildStatChip('ليل: $nightCount'),
                    const SizedBox(width: 8),
                    _buildStatChip('صفحات: $totalPages'),
                  ],
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: _getStatusColor(project.status).withValues(alpha: 0.2),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(
              _getStatusLabel(project.status),
              style: TextStyle(
                color: _getStatusColor(project.status),
                fontSize: 12,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatChip(String label) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(label, style: const TextStyle(fontSize: 10)),
    );
  }

  Widget _buildEmptyScenes(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.movie, size: 80, color: Colors.grey.shade400),
          const SizedBox(height: 16),
          Text('لا توجد مشاهد بعد',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text('اضغط على زر + لإضافة مشهد جديد',
              style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    );
  }

  Widget _buildScenesList(SceneProvider provider) {
    return ListView.builder(
      padding: const EdgeInsets.all(8),
      itemCount: provider.scenes.length,
      itemBuilder: (context, index) {
        return _buildSceneCard(context, provider.scenes[index]);
      },
    );
  }

  Widget _buildSceneCard(BuildContext context, Scene scene) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              '${scene.number}',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(
          scene.title.isNotEmpty ? scene.title : 'مشهد ${scene.number}',
        ),
        subtitle: Text('${scene.location} - ${_getTimeLabel(scene.timeOfDay)}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (scene.status == 'completed')
              const Icon(Icons.check_circle, color: Colors.green, size: 20),
            IconButton(
              icon: const Icon(Icons.edit, size: 20),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => EditorScreen(sceneId: scene.id),
                ),
              ),
            ),
            IconButton(
              icon: const Icon(Icons.delete, size: 20, color: Colors.red),
              onPressed: () => _deleteScene(context, scene.id),
            ),
          ],
        ),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => EditorScreen(sceneId: scene.id),
          ),
        ),
      ),
    );
  }

  void _showCreateSceneDialog(BuildContext context, String projectId) {
    final titleController = TextEditingController();
    final locationController = TextEditingController();
    String selectedTime = 'day';
    String selectedType = 'dialogue';

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('مشهد جديد'),
        content: StatefulBuilder(
          builder: (context, setDialogState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(labelText: 'عنوان المشهد'),
                  autofocus: true,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: locationController,
                  decoration: const InputDecoration(labelText: 'المكان'),
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedTime,
                  decoration: const InputDecoration(labelText: 'الوقت'),
                  items: ['day', 'night', 'sunrise', 'sunset'].map((time) {
                    return DropdownMenuItem(
                      value: time,
                      child: Text(_getTimeLabel(time)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedTime = value);
                    }
                  },
                ),
                const SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedType,
                  decoration: const InputDecoration(labelText: 'نوع المشهد'),
                  items: ['dialogue', 'action', 'montage'].map((type) {
                    return DropdownMenuItem(
                      value: type,
                      child: Text({
                            'dialogue': 'حوار',
                            'action': 'حدث',
                            'montage': 'مونتاج',
                          }[type] ??
                          type),
                    );
                  }).toList(),
                  onChanged: (value) {
                    if (value != null) {
                      setDialogState(() => selectedType = value);
                    }
                  },
                ),
              ],
            );
          },
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty) {
                final provider =
                    Provider.of<SceneProvider>(context, listen: false);
                await provider.createScene(
                  projectId: projectId,
                  title: titleController.text,
                  location: locationController.text,
                  timeOfDay: selectedTime,
                  sceneType: selectedType,
                );
                if (dialogContext.mounted) Navigator.pop(dialogContext);
              }
            },
            child: const Text('إنشاء'),
          ),
        ],
      ),
    );
  }

  void _deleteScene(BuildContext context, String sceneId) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('حذف المشهد'),
        content: const Text('هل أنت متأكد من حذف هذا المشهد؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء'),
          ),
          ElevatedButton(
            onPressed: () async {
              await Provider.of<SceneProvider>(context, listen: false)
                  .deleteScene(sceneId);
              if (dialogContext.mounted) Navigator.pop(dialogContext);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
  }

  Future<void> _printScript(
      BuildContext context, Project project, List<Scene> scenes) async {
    setState(() => _isBusy = true);
    try {
      await _printService.printScript(project, scenes);
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّرت الطباعة: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  Future<void> _exportScript(
      BuildContext context, Project project, List<Scene> scenes) async {
    setState(() => _isBusy = true);
    try {
      final file = await _exportService.exportProjectToPdf(project, scenes);
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تم التصدير إلى: ${file.path}')),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('تعذّر التصدير: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _isBusy = false);
    }
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'idea':
        return Colors.blue;
      case 'draft':
        return Colors.orange;
      case 'review':
        return Colors.purple;
      case 'final':
        return Colors.green;
      default:
        return Colors.grey;
    }
  }

  String _getStatusLabel(String status) {
    switch (status) {
      case 'idea':
        return 'فكرة';
      case 'draft':
        return 'مسودة';
      case 'review':
        return 'مراجعة';
      case 'final':
        return 'نهائي';
      default:
        return status;
    }
  }
}
