import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:flutter_colorpicker/flutter_colorpicker.dart';
import 'package:easy_localization/easy_localization.dart';
import '../providers/settings_provider.dart';
import '../../core/themes/theme_provider.dart';
import '../../core/utils/font_helper.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final settingsProvider = Provider.of<SettingsProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('settings'.tr()),
      ),
      body: ListView(
        children: [
          _buildSectionHeader(context, 'appearance'.tr()),
          _buildSwitchTile(
            context,
            icon: Icons.brightness_4,
            title: 'dark_mode'.tr(),
            value: themeProvider.themeMode == ThemeMode.dark,
            onChanged: (value) {
              themeProvider.setThemeMode(
                value ? ThemeMode.dark : ThemeMode.light,
              );
            },
          ),
          _buildSwitchTile(
            context,
            icon: Icons.auto_awesome,
            title: 'auto_theme'.tr(),
            value: settingsProvider.autoDetectTheme,
            onChanged: (value) {
              settingsProvider.setAutoDetectTheme(value);
              if (value) {
                themeProvider.autoDetectTheme();
              }
            },
          ),
          _buildColorPickerTile(
            context,
            icon: Icons.color_lens,
            title: 'primary_color'.tr(),
            color: settingsProvider.primaryColor,
            onChanged: (color) => settingsProvider.setPrimaryColor(color),
          ),
          _buildColorPickerTile(
            context,
            icon: Icons.text_fields,
            title: 'text_color'.tr(),
            color: settingsProvider.textColor,
            onChanged: (color) => settingsProvider.setTextColor(color),
          ),
          _buildDropdownTile<String>(
            context,
            icon: Icons.font_download,
            title: 'font_family'.tr(),
            value: settingsProvider.fontFamily,
            items: FontHelper.availableFonts,
            onChanged: (value) {
              if (value != null) settingsProvider.setFontFamily(value);
            },
          ),
          _buildSliderTile(
            context,
            icon: Icons.text_fields,
            title: 'font_size'.tr(),
            value: settingsProvider.fontSize,
            min: 12,
            max: 28,
            onChanged: (value) => settingsProvider.setFontSize(value),
          ),
          const Divider(),
          _buildSectionHeader(context, 'language'.tr()),
          _buildDropdownTile<String>(
            context,
            icon: Icons.language,
            title: 'default_language'.tr(),
            value: context.locale.languageCode,
            items: settingsProvider.availableLanguages,
            onChanged: (value) {
              if (value != null) {
                context.setLocale(Locale(value));
                settingsProvider.setDefaultLanguage(value);
              }
            },
            getLabel: (value) => settingsProvider.getLanguageName(value),
          ),
          const Divider(),
          _buildSectionHeader(context, 'script_type'.tr()),
          _buildDropdownTile<String>(
            context,
            icon: Icons.movie,
            title: 'script_type'.tr(),
            value: settingsProvider.scriptType,
            items: const ['film', 'series', 'play', 'novel', 'story', 'animation'],
            onChanged: (value) {
              if (value != null) settingsProvider.setScriptType(value);
            },
            getLabel: (value) => value.tr(),
          ),
          const Divider(),
          _buildSectionHeader(context, 'export_and_print'.tr()),
          ListTile(
            leading: const Icon(Icons.picture_as_pdf),
            title: Text('export_pdf'.tr()),
            trailing: const Icon(Icons.arrow_forward),
            onTap: () {},
          ),
          const Divider(),
          _buildSectionHeader(context, 'about_app'.tr()),
          ListTile(
            leading: const Icon(Icons.info),
            title: Text('about_app'.tr()),
            subtitle: Text('version'.tr() + ': 1.0.0'),
            onTap: () => _showAboutDialog(context),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          color: Theme.of(context).primaryColor,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildSwitchTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return SwitchListTile(
      secondary: Icon(icon),
      title: Text(title),
      value: value,
      onChanged: onChanged,
    );
  }

  Widget _buildColorPickerTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required Color color,
    required ValueChanged<Color> onChanged,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: GestureDetector(
        onTap: () => _showColorPicker(context, color, onChanged),
        child: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: color,
            shape: BoxShape.circle,
            border: Border.all(color: Colors.grey.shade300),
          ),
        ),
      ),
    );
  }

  void _showColorPicker(BuildContext context, Color initialColor, ValueChanged<Color> onChanged) {
    Color selectedColor = initialColor;
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('select'.tr()),
        content: SingleChildScrollView(
          child: ColorPicker(
            pickerColor: selectedColor,
            onColorChanged: (color) => selectedColor = color,
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text('cancel'.tr())),
          TextButton(
            onPressed: () {
              onChanged(selectedColor);
              Navigator.pop(dialogContext);
            },
            child: Text('select'.tr()),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownTile<T>(
    BuildContext context, {
    required IconData icon,
    required String title,
    required T value,
    required List<T> items,
    required ValueChanged<T?> onChanged,
    String Function(T)? getLabel,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      trailing: DropdownButton<T>(
        value: value,
        items: items
            .map((item) => DropdownMenuItem(
                  value: item,
                  child: Text(getLabel != null ? getLabel(item) : item.toString()),
                ))
            .toList(),
        onChanged: onChanged,
      ),
    );
  }

  Widget _buildSliderTile(
    BuildContext context, {
    required IconData icon,
    required String title,
    required double value,
    required double min,
    required double max,
    required ValueChanged<double> onChanged,
  }) {
    return ListTile(
      leading: Icon(icon),
      title: Text(title),
      subtitle: Slider(
        value: value,
        min: min,
        max: max,
        divisions: 16,
        label: value.toStringAsFixed(1),
        onChanged: onChanged,
      ),
      trailing: Text(value.toStringAsFixed(1)),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: Text('about_app'.tr()),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.edit, size: 60, color: Color(0xFFD4AF37)),
            const SizedBox(height: 16),
            Text('app_title'.tr(), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text('version'.tr() + ': 1.0.0'),
            const SizedBox(height: 8),
            Text('copyright'.tr()),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: Text('close'.tr())),
        ],
      ),
    );
  }
}
