import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/scene_provider.dart';
import '../providers/settings_provider.dart';
import '../../data/models/scene.dart';
import '../../services/translation_service.dart';

class TranslationScreen extends StatefulWidget {
  final String projectId;
  const TranslationScreen({super.key, required this.projectId});

  @override
  State<TranslationScreen> createState() => _TranslationScreenState();
}

class _TranslationScreenState extends State<TranslationScreen> {
  String _selectedLanguage = 'en';
  bool _isTranslating = false;
  final _translationService = TranslationService();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      Provider.of<SceneProvider>(context, listen: false)
          .loadScenes(widget.projectId);
    });
  }

  @override
  Widget build(BuildContext context) {
    final sceneProvider = Provider.of<SceneProvider>(context);
    final settingsProvider = Provider.of<SettingsProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('ترجمة ودبلجة السيناريو'),
        actions: [
          if (_isTranslating)
            const Padding(
              padding: EdgeInsets.all(8.0),
              child: SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              ),
            ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: Theme.of(context).primaryColor.withValues(alpha: 0.05),
              border: Border(
                bottom: BorderSide(color: Colors.grey.shade300),
              ),
            ),
            child: Column(
              children: [
                DropdownButtonFormField<String>(
                  value: _selectedLanguage,
                  decoration: const InputDecoration(labelText: 'لغة الترجمة'),
                  items: settingsProvider.availableLanguages
                      .where((lang) => lang != 'ar')
                      .map((lang) => DropdownMenuItem(
                            value: lang,
                            child: Text(settingsProvider.getLanguageName(lang)),
                          ))
                      .toList(),
                  onChanged: (value) {
                    if (value != null) setState(() => _selectedLanguage = value);
                  },
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        onPressed: _isTranslating
                            ? null
                            : () => _translateAllScenes(sceneProvider),
                        icon: const Icon(Icons.translate),
                        label: const Text('ترجمة كل المشاهد'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: _isTranslating
                            ? null
                            : () => _exportTranslatedScript(sceneProvider),
                        icon: const Icon(Icons.file_download),
                        label: const Text('تصدير الترجمة'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  'ملاحظة: الترجمة تتم فعلياً عبر خدمة MyMemory المجانية '
                  'وتحتاج اتصالاً بالإنترنت. للنصوص الطويلة جداً يتم '
                  'تقسيمها تلقائياً على عدة طلبات.',
                  style: TextStyle(
                    fontSize: 11,
                    color: Colors.grey.shade600,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          Expanded(
            child: sceneProvider.isLoading
                ? const Center(child: CircularProgressIndicator())
                : sceneProvider.scenes.isEmpty
                    ? const Center(child: Text('لا توجد مشاهد للترجمة'))
                    : ListView.builder(
                        itemCount: sceneProvider.scenes.length,
                        itemBuilder: (context, index) {
                          return _buildTranslationItem(
                            context,
                            sceneProvider.scenes[index],
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }

  Widget _buildTranslationItem(BuildContext context, Scene scene) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ExpansionTile(
        leading: Container(
          width: 35,
          height: 35,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              '${scene.number}',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(
          scene.title.isNotEmpty ? scene.title : 'مشهد ${scene.number}',
        ),
        subtitle: Text('${scene.location} - ${_getTimeLabel(scene.timeOfDay)}'),
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (scene.dialogue.isNotEmpty) ...[
                  const Text('النص الأصلي:',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  Container(
                    padding: const EdgeInsets.all(8),
                    margin: const EdgeInsets.only(top: 4, bottom: 8),
                    decoration: BoxDecoration(
                      color: Colors.grey.shade100,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(scene.dialogue),
                  ),
                ],
                const Text('الترجمة:', style: TextStyle(fontWeight: FontWeight.bold)),
                Container(
                  padding: const EdgeInsets.all(8),
                  margin: const EdgeInsets.only(top: 4),
                  decoration: BoxDecoration(
                    color: Theme.of(context).primaryColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    scene.translation.isNotEmpty
                        ? scene.translation
                        : 'لم يتم الترجمة بعد',
                    style: TextStyle(
                      color: scene.translation.isNotEmpty ? null : Colors.grey.shade500,
                    ),
                  ),
                ),
                if (scene.translation.isEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: TextButton.icon(
                      onPressed: () => _translateSingleScene(scene),
                      icon: const Icon(Icons.translate, size: 16),
                      label: const Text('ترجمة هذا المشهد'),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _translateSingleScene(Scene scene) async {
    if (scene.dialogue.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يوجد حوار في هذا المشهد لترجمته')),
      );
      return;
    }

    setState(() => _isTranslating = true);

    try {
      final translatedText = await _translationService.translateText(
        text: scene.dialogue,
        targetLanguage: _selectedLanguage,
      );

      final updatedScene = scene.copyWith(translation: translatedText);

      if (!mounted) return;
      await Provider.of<SceneProvider>(context, listen: false)
          .updateScene(updatedScene);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تمت ترجمة المشهد بنجاح')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذّرت الترجمة: $e')),
      );
    } finally {
      if (mounted) setState(() => _isTranslating = false);
    }
  }

  void _translateAllScenes(SceneProvider provider) async {
    setState(() => _isTranslating = true);
    var failedCount = 0;

    for (var scene in List<Scene>.from(provider.scenes)) {
      if (scene.dialogue.trim().isEmpty) continue;
      try {
        final translatedText = await _translationService.translateText(
          text: scene.dialogue,
          targetLanguage: _selectedLanguage,
        );
        final updatedScene = scene.copyWith(translation: translatedText);
        await provider.updateScene(updatedScene);
      } catch (_) {
        failedCount++;
      }
    }

    if (!mounted) return;
    setState(() => _isTranslating = false);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          failedCount == 0
              ? 'تمت ترجمة كل المشاهد بنجاح'
              : 'تمت الترجمة مع فشل $failedCount مشهد (تحقق من الاتصال بالإنترنت)',
        ),
      ),
    );
  }

  void _exportTranslatedScript(SceneProvider provider) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'استخدم زر "تصدير السيناريو" داخل شاشة المشروع بعد الترجمة؛ '
          'حقل الترجمة سيظهر تلقائياً مع بقية بيانات كل مشهد.',
        ),
      ),
    );
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }
}
