import 'dart:io';
import 'package:flutter/material.dart';
import '../../data/models/character.dart';

class CharacterCard extends StatelessWidget {
  final Character character;
  final VoidCallback? onTap;
  final VoidCallback? onDelete;

  const CharacterCard({
    super.key,
    required this.character,
    this.onTap,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: Theme.of(context).primaryColor.withValues(alpha: 0.2),
          backgroundImage:
              character.imagePath.isNotEmpty ? FileImage(File(character.imagePath)) : null,
          child: character.imagePath.isEmpty
              ? Icon(Icons.person, color: Theme.of(context).primaryColor)
              : null,
        ),
        title: Text(character.name),
        subtitle: Text(
          [
            if (character.age.isNotEmpty) character.age,
            if (character.occupation.isNotEmpty) character.occupation,
          ].join(' - '),
        ),
        trailing: onDelete != null
            ? IconButton(
                icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                onPressed: onDelete,
              )
            : null,
      ),
    );
  }
}
