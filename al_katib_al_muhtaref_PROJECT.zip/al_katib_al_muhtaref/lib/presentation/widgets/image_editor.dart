import 'dart:io';
import 'package:flutter/material.dart';
import '../../data/models/image_asset.dart';

/// محرر صورة فعلي يسمح بالسحب وتغيير الحجم، بدلاً من الزر الوهمي الذي
/// كان يعرض SnackBar فقط في editor_screen.dart الأصلي.
class ImageEditor extends StatefulWidget {
  final ImageAsset image;
  final ValueChanged<ImageAsset> onChanged;

  const ImageEditor({
    super.key,
    required this.image,
    required this.onChanged,
  });

  @override
  State<ImageEditor> createState() => _ImageEditorState();
}

class _ImageEditorState extends State<ImageEditor> {
  late double _x;
  late double _y;
  late double _width;
  late double _height;

  @override
  void initState() {
    super.initState();
    _x = widget.image.xPosition;
    _y = widget.image.yPosition;
    _width = widget.image.width;
    _height = widget.image.height;
  }

  void _emitChange() {
    widget.onChanged(
      ImageAsset(
        id: widget.image.id,
        sceneId: widget.image.sceneId,
        imagePath: widget.image.imagePath,
        xPosition: _x,
        yPosition: _y,
        width: _width,
        height: _height,
        rotation: widget.image.rotation,
        createdAt: widget.image.createdAt,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.black87,
      child: Stack(
        children: [
          Positioned(
            left: _x,
            top: _y,
            child: GestureDetector(
              onPanUpdate: (details) {
                setState(() {
                  _x += details.delta.dx;
                  _y += details.delta.dy;
                });
              },
              onPanEnd: (_) => _emitChange(),
              child: Image.file(
                File(widget.image.imagePath),
                width: _width,
                height: _height,
                fit: BoxFit.contain,
              ),
            ),
          ),
          Positioned(
            left: _x + _width - 12,
            top: _y + _height - 12,
            child: GestureDetector(
              onPanUpdate: (details) {
                setState(() {
                  _width = (_width + details.delta.dx).clamp(20.0, 800.0);
                  _height = (_height + details.delta.dy).clamp(20.0, 800.0);
                });
              },
              onPanEnd: (_) => _emitChange(),
              child: Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.black),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.open_in_full, size: 14),
              ),
            ),
          ),
          Positioned(
            top: 16,
            right: 16,
            child: IconButton(
              icon: const Icon(Icons.close, color: Colors.white),
              onPressed: () => Navigator.of(context).pop(),
            ),
          ),
        ],
      ),
    );
  }
}
