import 'package:flutter/material.dart';
import '../../data/models/scene.dart';

/// ويدجت بطاقة مشهد مستقلة، كانت مذكورة في هيكل المجلدات الأصلي لكنها لم
/// تُنشأ فعلياً، مما أدى لتكرار نفس الكود داخل كل من project_screen.dart
/// و translation_screen.dart.
class SceneCard extends StatelessWidget {
  final Scene scene;
  final VoidCallback? onTap;
  final VoidCallback? onEdit;
  final VoidCallback? onDelete;

  const SceneCard({
    super.key,
    required this.scene,
    this.onTap,
    this.onEdit,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: Theme.of(context).primaryColor.withValues(alpha: 0.2),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Center(
            child: Text(
              '${scene.number}',
              style: TextStyle(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),
        title: Text(scene.title.isNotEmpty ? scene.title : 'مشهد ${scene.number}'),
        subtitle: Text('${scene.location} - ${_getTimeLabel(scene.timeOfDay)}'),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (scene.status == 'completed')
              const Icon(Icons.check_circle, color: Colors.green, size: 20),
            if (onEdit != null)
              IconButton(
                icon: const Icon(Icons.edit, size: 20),
                onPressed: onEdit,
              ),
            if (onDelete != null)
              IconButton(
                icon: const Icon(Icons.delete, size: 20, color: Colors.red),
                onPressed: onDelete,
              ),
          ],
        ),
      ),
    );
  }

  String _getTimeLabel(String time) {
    switch (time) {
      case 'day':
        return 'نهار';
      case 'night':
        return 'ليل';
      case 'sunrise':
        return 'شروق';
      case 'sunset':
        return 'غروب';
      default:
        return 'نهار';
    }
  }
}
