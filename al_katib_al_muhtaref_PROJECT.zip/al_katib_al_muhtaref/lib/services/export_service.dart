import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../data/models/project.dart';
import '../data/models/scene.dart';
import 'script_formatter.dart';

/// خدمة تصدير حقيقية للسيناريو بصيغة PDF، بتنسيق عالمي مختلف حسب نوع
/// الكتابة (فيلم/مسلسل/كرتون بتنسيق Screenplay القياسي، مسرحية بتنسيق
/// مسرحي، رواية/قصة بتنسيق مخطوطة أدبية) عبر ScriptFormatter.
class ExportService {
  Future<File> exportProjectToPdf(Project project, List<Scene> scenes) async {
    final pdf = ScriptFormatter.buildDocument(project, scenes);

    final dir = await getApplicationDocumentsDirectory();
    final fileName =
        '${project.title.replaceAll(RegExp(r'[^\w\s]'), '_')}.pdf';
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(await pdf.save());
    return file;
  }
}
