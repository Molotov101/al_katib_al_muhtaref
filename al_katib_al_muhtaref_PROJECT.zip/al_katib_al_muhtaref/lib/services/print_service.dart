import 'package:printing/printing.dart';
import '../data/models/project.dart';
import '../data/models/scene.dart';
import 'script_formatter.dart';

/// خدمة طباعة حقيقية تستخدم نفس منسّق السيناريو حسب النوع (ScriptFormatter)
/// المستخدم في التصدير، حتى تتطابق نسخة الطباعة مع نسخة التصدير تماماً.
class PrintService {
  Future<void> printScript(Project project, List<Scene> scenes) async {
    final pdf = ScriptFormatter.buildDocument(project, scenes);
    await Printing.layoutPdf(
      onLayout: (format) async => pdf.save(),
    );
  }
}
