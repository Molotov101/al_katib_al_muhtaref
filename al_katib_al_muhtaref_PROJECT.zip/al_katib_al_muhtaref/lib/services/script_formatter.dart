import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../data/models/project.dart';
import '../data/models/scene.dart';

class ScriptFormatter {
  static Future<pw.Document> buildDocument(Project project, List<Scene> scenes) async {
    // تحميل الخط العربي لدعم النصوص في PDF
    // ملاحظة: في بيئة التطبيق الحقيقية يجب التأكد من وجود الملف في assets
    final fontData = await rootBundle.load("assets/fonts/Cairo-Regular.ttf");
    final arabicFont = pw.Font.ttf(fontData);

    switch (project.type) {
      case 'film':
      case 'series':
      case 'animation':
        return _buildScreenplayFormat(project, scenes, arabicFont);
      case 'play':
        return _buildStagePlayFormat(project, scenes, arabicFont);
      case 'novel':
      case 'story':
        return _buildManuscriptFormat(project, scenes, arabicFont);
      default:
        return _buildScreenplayFormat(project, scenes, arabicFont);
    }
  }

  static pw.Document _buildScreenplayFormat(
      Project project, List<Scene> scenes, pw.Font font) {
    final pdf = pw.Document();
    
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        theme: pw.ThemeData.withFont(base: font),
        textDirection: pw.TextDirection.rtl,
        build: (context) => [
          pw.Header(level: 0, child: pw.Text(project.title, style: pw.TextStyle(fontSize: 24))),
          pw.SizedBox(height: 20),
          for (final scene in scenes) ...[
            pw.Text('المشهد ${scene.number}: ${scene.location}', 
                   style: pw.TextStyle(fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 10),
            pw.Text(scene.description),
            pw.SizedBox(height: 10),
            pw.Center(child: pw.Text(scene.dialogue)),
            pw.SizedBox(height: 20),
          ]
        ],
      ),
    );
    return pdf;
  }

  static pw.Document _buildStagePlayFormat(Project project, List<Scene> scenes, pw.Font font) {
    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: font),
        textDirection: pw.TextDirection.rtl,
        build: (context) => [
          pw.Center(child: pw.Text(project.title, style: pw.TextStyle(fontSize: 22))),
          pw.SizedBox(height: 20),
          for (final scene in scenes) ...[
            pw.Text('المشهد ${scene.number}', style: pw.TextStyle(fontSize: 18)),
            pw.Text(scene.dialogue),
            pw.SizedBox(height: 15),
          ]
        ],
      ),
    );
    return pdf;
  }

  static pw.Document _buildManuscriptFormat(Project project, List<Scene> scenes, pw.Font font) {
    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        theme: pw.ThemeData.withFont(base: font),
        textDirection: pw.TextDirection.rtl,
        build: (context) => [
          pw.Text(project.title, style: pw.TextStyle(fontSize: 26)),
          pw.SizedBox(height: 20),
          for (final scene in scenes) ...[
            pw.Text(scene.description, textAlign: pw.TextAlign.justify),
            pw.SizedBox(height: 10),
          ]
        ],
      ),
    );
    return pdf;
  }
}
