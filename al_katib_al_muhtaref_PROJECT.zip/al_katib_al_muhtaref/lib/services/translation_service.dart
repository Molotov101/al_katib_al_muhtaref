import 'dart:convert';
import 'package:http/http.dart' as http;

/// خدمة ترجمة فعلية باستخدام MyMemory Translation API.
///
/// ملاحظة تصحيح مهمة: النسخة السابقة من هذا الملف اقترحت استخدام
/// libretranslate.com بدون مفتاح. تحقّقنا فعلياً والخدمة العامة على
/// libretranslate.com أصبحت تتطلب الآن مفتاح API مدفوعاً (تحديث حديث من
/// مالكي الخدمة)، فتم استبدالها بـ MyMemory التي لا تزال مجانية فعلاً
/// وبلا أي مفتاح حتى الآن، لكنها محدودة بحد أقصى ~500 حرف لكل طلب،
/// لذلك تقوم هذه الخدمة بتقسيم النص الطويل إلى أجزاء صغيرة تلقائياً.
class TranslationService {
  static const String _endpoint = 'https://api.mymemory.translated.net/get';
  static const int _maxChunkLength = 450;

  Future<String> translateText({
    required String text,
    required String targetLanguage,
    String sourceLanguage = 'ar',
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return '';

    final chunks = _splitIntoChunks(trimmed, _maxChunkLength);
    final translatedChunks = <String>[];

    for (final chunk in chunks) {
      translatedChunks.add(
        await _translateChunk(
          text: chunk,
          source: sourceLanguage,
          target: targetLanguage,
        ),
      );
    }

    return translatedChunks.join(' ');
  }

  Future<String> _translateChunk({
    required String text,
    required String source,
    required String target,
  }) async {
    final uri = Uri.https('api.mymemory.translated.net', '/get', {
      'q': text,
      'langpair': '$source|$target',
    });

    final response = await http.get(uri).timeout(const Duration(seconds: 15));

    if (response.statusCode != 200) {
      throw Exception('فشل طلب الترجمة: ${response.statusCode}');
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final responseData = data['responseData'] as Map<String, dynamic>?;
    final translated = responseData?['translatedText'] as String?;

    if (translated == null || translated.isEmpty) {
      throw Exception('لم يُرجع المزوّد أي نص مترجم');
    }
    return translated;
  }

  /// يقسّم النص إلى أجزاء لا يتجاوز طول كل منها maxLength حرفاً، محاولاً
  /// التقسيم عند نهاية جملة أو سطر بدل تقطيع كلمة من المنتصف.
  List<String> _splitIntoChunks(String text, int maxLength) {
    if (text.length <= maxLength) return [text];

    final chunks = <String>[];
    var remaining = text;

    while (remaining.length > maxLength) {
      var cutIndex = remaining.lastIndexOf('.', maxLength);
      if (cutIndex < maxLength ~/ 2) {
        cutIndex = remaining.lastIndexOf(' ', maxLength);
      }
      if (cutIndex <= 0) {
        cutIndex = maxLength;
      }
      chunks.add(remaining.substring(0, cutIndex + 1).trim());
      remaining = remaining.substring(cutIndex + 1).trim();
    }
    if (remaining.isNotEmpty) chunks.add(remaining);

    return chunks;
  }
}
